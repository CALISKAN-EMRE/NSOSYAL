import os
from pathlib import Path
from typing import List, Optional, Union
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application configuration settings."""

    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    APP_NAME: str = "NSosyal Pusula"
    APP_VERSION: str = "0.2.0"

    HOST: str = "0.0.0.0"
    PORT: int = 8000

    CORS_ORIGINS: Union[str, List[str]] = "http://localhost:3000,http://127.0.0.1:3000"

    DATA_SOURCE_TYPE: str = "json"
    DEMO_DATA_PATH: str = str(
        Path(__file__).resolve().parent.parent.parent / "data" / "demo_posts.json"
    )

    # Semantic ML Runtime Mode: "ml" (CUDA / Local Models) or "demo" (Deterministic Fallback)
    SEMANTIC_MODE: str = os.getenv("SEMANTIC_MODE", "ml")
    DEVICE: Optional[str] = os.getenv("DEVICE", None)  # Auto-detects cuda/cpu if None

    # Model IDs for Phase 2 Production ML Architecture
    MODEL_CLUSTERING_EMBED: str = "ytu-ce-cosmos/modernbert-tr-embed"
    MODEL_SEARCH_EMBED: str = "intfloat/multilingual-e5-large-instruct"
    MODEL_CONTEXT_RERANKER: str = "ytu-ce-cosmos/modernbert-tr-reranker"
    MODEL_GUARDRAIL: str = "ytu-ce-cosmos/modernbert-tr-guardrail"
    RERANKER_TOP_K: int = 15

    # Moderation & Recommendation providers
    AI_MODERATION_PROVIDER: str = "modernbert_guardrail"
    AI_RECOMMENDATION_PROVIDER: str = "semantic_multi_factor"

    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, v: Union[str, List[str]]) -> List[str]:
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v


settings = Settings()
